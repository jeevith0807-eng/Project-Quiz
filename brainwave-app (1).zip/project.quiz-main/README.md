# Brain Wave as an app

## Run on your PC (Windows)
1. Install Python 3.10+ from python.org (tick "Add Python to PATH").
2. Double-click **BrainWave.bat**. First run installs everything (about a minute), then Brain Wave opens in its own app window (Edge/Chrome app mode, no browser tabs).
3. Mac/Linux: run `./brainwave.sh`.

## Public link from your PC (temporary)
Install once: `winget install Cloudflare.cloudflared`, then double-click **BrainWave-Public.bat**. A `https://...trycloudflare.com` link prints in the window; anyone can open it while your PC is on.

## Permanent public app (recommended)
Push to GitHub, then Render > New > Blueprint (uses render.yaml). You get a permanent https URL.

## Install on phone / desktop like a real app
Open the public https URL in Chrome/Edge/Safari and choose **Install app** / **Add to Home Screen**. Brain Wave has a manifest, icons and a service worker, so it opens full-screen with its own icon.

---

# Brain Wave 🧠⚡

A quiz website built with **Python (Flask)**, **HTML/CSS/JS**, and **SQL**, deployable via **GitHub + Render**.

Players can sign up (or join as a guest), create their own quizzes, attend quizzes made by
others, play a featured "Quiz of the Day", and climb a points leaderboard.

---

## 1. Folder structure

```
brainwave/
├── app.py                  # All Flask routes (sign up, login, quizzes, leaderboard...)
├── config.py                # Reads database settings from environment variables
├── extensions.py            # Shared db + login_manager objects
├── models.py                 # Database tables: User, Quiz, Question, Attempt
├── requirements.txt          # Python packages this project needs
├── render.yaml                # Optional: one-click Render deployment config
├── .gitignore
├── .env.example
├── static/
│   ├── css/
│   │   └── style.css        # All the site's visual styling
│   └── js/
│       ├── script.js         # Small site-wide behaviour (auto-hide messages)
│       └── quiz_builder.js   # Add/remove questions on the "Create Quiz" page
└── templates/
    ├── base.html              # Shared layout: navbar + page wrapper
    ├── login.html
    ├── signup.html
    ├── home.html
    ├── create_quiz.html
    ├── attend_quiz.html
    ├── take_quiz.html
    ├── quiz_result.html
    ├── quiz_of_day.html
    └── leaderboard.html
```

**Why this structure?** Flask expects HTML files in a folder called `templates/` and
CSS/JS/images in a folder called `static/` — that's not optional, it's a Flask convention.
Everything else (`models.py`, `config.py`, `extensions.py`) is just good practice for
keeping code organised as the project grows, instead of dumping everything into one file.

---

## 2. A couple of things I changed from your plan (and why)

**Facebook/Gmail login → simple email + password login (with guest mode)**
Real "Sign in with Google/Facebook" requires you to register a developer app with Google
Cloud / Meta, get approved, and configure callback URLs — that's a lot of setup for a
school project, and it doesn't run anywhere except a properly configured live domain.
I built a normal, secure email + password system instead (passwords are hashed, never
stored as plain text), plus **Guest Mode**, which is the fastest way to jump in and
still shows up on the leaderboard. If your teacher specifically wants real Google
sign-in, see the **"Optional: adding real Google login"** section at the bottom —
it's a good stretch goal once the core site works.

**HeidiSQL → SQLite (local) / PostgreSQL (on Render)**
HeidiSQL is just a *viewer/editor tool* for MySQL databases — it isn't a database
itself, and Render doesn't offer free MySQL hosting. So this project uses:
- **SQLite** automatically when you run it on your own computer (zero setup, it's just
  a file called `brainwave.db`).
- **PostgreSQL** automatically when deployed on Render (Render gives you a free Postgres
  database and connects it via one environment variable).

You can still install HeidiSQL on your laptop if you want a visual tool to browse a
MySQL database for a different part of your coursework — it just isn't what powers
this particular site.

---

## 3. Running it on your own computer

You need **Python 3.10+** installed first.

```bash
# 1. Go into the project folder
cd brainwave

# 2. Create a virtual environment (keeps this project's packages separate)
python -m venv venv

# 3. Activate it
venv\Scripts\activate        # Windows
source venv/bin/activate     # Mac/Linux

# 4. Install dependencies
pip install -r requirements.txt

# 5. Run the app
python app.py
```

Open **http://127.0.0.1:5000** in your browser. The database file (`brainwave.db`) and
all its tables are created automatically the first time you run it — no separate
setup command needed.

---

## 4. Putting it on GitHub

```bash
git init
git add .
git commit -m "Initial commit: Brain Wave quiz app"
```

Then create a new empty repository on [github.com](https://github.com), and:

```bash
git remote add origin https://github.com/YOUR-USERNAME/brainwave.git
git branch -M main
git push -u origin main
```

`.gitignore` already makes sure your local `venv/` folder and `brainwave.db` file don't
get uploaded — those are meant to stay on your computer only.

---

## 5. Deploying on Render

1. Go to [render.com](https://render.com) and sign in with your GitHub account.
2. Click **New +** → **Blueprint**, and pick your `brainwave` repository.
   Render will read `render.yaml` and automatically set up:
   - A **web service** running `gunicorn app:app`
   - A free **PostgreSQL database**, already linked via the `DATABASE_URL` variable
   - A random `SECRET_KEY`

   *(If you'd rather set it up manually instead of using the Blueprint: New + → Web
   Service → connect your repo → Build Command `pip install -r requirements.txt` →
   Start Command `gunicorn app:app`. Then New + → PostgreSQL to create a database, and
   copy its "Internal Database URL" into your web service's Environment tab as
   `DATABASE_URL`.)*
3. Click **Apply** / **Create Web Service** and wait for the first deploy to finish.
4. Your site will be live at a URL like `https://brainwave.onrender.com`.

Every time you `git push` to `main`, Render automatically redeploys the latest version.

---

## 6. How the quiz logic works

- **Create Quiz**: you fill in a title + category, then click **"+ Add question"** for
  each question. Each question has 4 text options and a radio button to mark which one
  is correct. On submit, the quiz and all its questions are saved to the database.
- **Attend Quiz**: lists every published quiz, with a search box and category filter
  ("classified" by category, as you asked).
- **Quiz of the Day**: picks the same quiz for everyone using today's date as a seed —
  it changes automatically at midnight without needing an admin to update anything.
- **Scoring**: submitting answers awards **10 points per correct answer**, added
  straight to your account, which is what powers the **Leaderboard** (top 20 players,
  sorted by total points).

---

## 7. Optional: adding real Google login (stretch goal)

If you want actual "Sign in with Google" later:
1. Create a project in the [Google Cloud Console](https://console.cloud.google.com/)
   and set up an **OAuth consent screen** + **OAuth Client ID** (type: Web application).
2. Add `pip install Authlib` to your project.
3. Use Authlib's Flask integration to redirect to Google and receive the user's email
   back at a `/auth/callback` route, then create/log in a `User` with that email —
   the `User` model here already supports it since `password_hash` is optional.

This is genuinely more setup than most beginner school projects need, so I'd recommend
treating it as a bonus once the rest of the site is working and demoed.
# project.quiz

