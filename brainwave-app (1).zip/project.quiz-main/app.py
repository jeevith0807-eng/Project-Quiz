import random
from datetime import date

from flask import Flask, send_from_directory, render_template, redirect, url_for, request, flash, session
from flask_login import (
    login_user,
    logout_user,
    login_required,
    current_user,
)

from config import Config
from extensions import db, login_manager
from models import User, Quiz, Question, Attempt


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = "login"
    login_manager.login_message = "Please sign in to continue."

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    # Create tables automatically if they don't exist yet. This runs both
    # when you start the app locally AND when Render starts it with
    # gunicorn, so you never have to run a separate setup command.
    with app.app_context():
        db.create_all()

    # ---------- PWA ROUTES ----------

    @app.route("/sw.js")
    def service_worker():
        resp = send_from_directory(app.static_folder, "sw.js", mimetype="application/javascript")
        resp.headers["Cache-Control"] = "no-cache"
        resp.headers["Service-Worker-Allowed"] = "/"
        return resp

    @app.route("/offline")
    def offline():
        return render_template("offline.html")

    # ---------- AUTH ROUTES ----------

    @app.route("/")
    def index():
        if current_user.is_authenticated:
            return redirect(url_for("home"))
        return redirect(url_for("login"))

    @app.route("/signup", methods=["GET", "POST"])
    def signup():
        if request.method == "POST":
            username = request.form.get("username", "").strip()
            email = request.form.get("email", "").strip()
            password = request.form.get("password", "")

            if not username or not email or not password:
                flash("Please fill in all fields.", "error")
                return redirect(url_for("signup"))

            if User.query.filter_by(email=email).first():
                flash("An account with that email already exists.", "error")
                return redirect(url_for("signup"))

            if User.query.filter_by(username=username).first():
                flash("That username is taken. Try another.", "error")
                return redirect(url_for("signup"))

            user = User(username=username, email=email)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()

            login_user(user)
            flash(f"Welcome to Brain Wave, {username}!", "success")
            return redirect(url_for("home"))

        return render_template("signup.html")

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            email = request.form.get("email", "").strip()
            password = request.form.get("password", "")

            user = User.query.filter_by(email=email).first()
            if user and user.check_password(password):
                login_user(user)
                return redirect(url_for("home"))

            flash("Incorrect email or password.", "error")
            return redirect(url_for("login"))

        return render_template("login.html")

    @app.route("/guest")
    def guest_login():
        guest = User.make_guest()
        login_user(guest)
        flash(f"Playing as {guest.username}. Sign up anytime to save your progress!", "success")
        return redirect(url_for("home"))

    @app.route("/logout")
    @login_required
    def logout():
        logout_user()
        return redirect(url_for("login"))

    # ---------- MAIN APP ROUTES ----------

    @app.route("/home")
    @login_required
    def home():
        quiz_count = Quiz.query.count()
        top_players = User.query.order_by(User.points.desc()).limit(5).all()
        return render_template("home.html", quiz_count=quiz_count, top_players=top_players)

    @app.route("/create-quiz", methods=["GET", "POST"])
    @login_required
    def create_quiz():
        if request.method == "POST":
            title = request.form.get("title", "").strip()
            category = request.form.get("category", "").strip()

            if not title or not category:
                flash("Give your quiz a title and category.", "error")
                return redirect(url_for("create_quiz"))

            quiz = Quiz(title=title, category=category, creator_id=current_user.id)
            db.session.add(quiz)
            db.session.commit()

            # Questions arrive as parallel lists: question_1, option_a_1, ...
            question_texts = request.form.getlist("question_text")
            options_a = request.form.getlist("option_a")
            options_b = request.form.getlist("option_b")
            options_c = request.form.getlist("option_c")
            options_d = request.form.getlist("option_d")
            correct_options = request.form.getlist("correct_option")

            added = 0
            for i in range(len(question_texts)):
                if not question_texts[i].strip():
                    continue
                q = Question(
                    quiz_id=quiz.id,
                    question_text=question_texts[i].strip(),
                    option_a=options_a[i].strip(),
                    option_b=options_b[i].strip(),
                    option_c=options_c[i].strip(),
                    option_d=options_d[i].strip(),
                    correct_option=correct_options[i],
                )
                db.session.add(q)
                added += 1

            if added == 0:
                db.session.delete(quiz)
                db.session.commit()
                flash("Add at least one question before publishing.", "error")
                return redirect(url_for("create_quiz"))

            db.session.commit()
            flash("Your quiz is live! Other players can attend it now.", "success")
            return redirect(url_for("home"))

        return render_template("create_quiz.html")

    @app.route("/attend-quiz")
    @login_required
    def attend_quiz():
        search = request.args.get("category", "").strip()
        query = Quiz.query
        if search:
            query = query.filter(Quiz.category.ilike(f"%{search}%"))
        quizzes = query.order_by(Quiz.created_at.desc()).all()

        categories = sorted({q.category for q in Quiz.query.all()})
        return render_template("attend_quiz.html", quizzes=quizzes, categories=categories, search=search)

    @app.route("/quiz/<int:quiz_id>", methods=["GET", "POST"])
    @login_required
    def take_quiz(quiz_id):
        quiz = Quiz.query.get_or_404(quiz_id)

        if request.method == "POST":
            score = 0
            results = []
            for question in quiz.questions:
                submitted = request.form.get(f"question_{question.id}")
                is_correct = submitted == question.correct_option
                if is_correct:
                    score += 1
                results.append({
                    "question": question,
                    "submitted": submitted,
                    "is_correct": is_correct,
                })

            attempt = Attempt(
                user_id=current_user.id,
                quiz_id=quiz.id,
                score=score,
                total_questions=len(quiz.questions),
            )
            db.session.add(attempt)

            # points: 10 per correct answer, added to the player's running total
            current_user.points += score * 10
            db.session.commit()

            return render_template(
                "quiz_result.html", quiz=quiz, results=results, score=score, total=len(quiz.questions)
            )

        return render_template("take_quiz.html", quiz=quiz)

    @app.route("/quiz-of-the-day")
    @login_required
    def quiz_of_the_day():
        all_quizzes = Quiz.query.all()
        featured = None
        if all_quizzes:
            # Same "random" quiz all day, changes automatically at midnight,
            # since the seed is today's date.
            rng = random.Random(date.today().isoformat())
            featured = rng.choice(all_quizzes)
        return render_template("quiz_of_day.html", quiz=featured)

    @app.route("/leaderboard")
    @login_required
    def leaderboard():
        players = User.query.order_by(User.points.desc()).limit(20).all()
        return render_template("leaderboard.html", players=players)

    return app


app = create_app()

if __name__ == "__main__":
    import os
    # HOST=0.0.0.0 lets phones on the same Wi-Fi open the app too.
    app.run(host=os.environ.get("HOST", "127.0.0.1"),
            port=int(os.environ.get("PORT", 5000)),
            debug=os.environ.get("FLASK_DEBUG", "0") == "1")
