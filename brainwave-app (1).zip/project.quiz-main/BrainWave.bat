@echo off
cd /d "%~dp0"
where python >nul 2>nul || (echo Python 3.10+ is required: https://www.python.org/downloads/ ^(tick "Add to PATH"^) & pause & exit /b)
if not exist venv (
  echo First run: setting things up, please wait...
  python -m venv venv
  venv\Scripts\python -m pip install -q -r requirements.txt
)
venv\Scripts\python launcher.py %*
pause
