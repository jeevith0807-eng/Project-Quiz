document.addEventListener("DOMContentLoaded", function () {
  // Fade out flash messages (success/error banners) after a few seconds.
  const flashes = document.querySelectorAll(".flash");
  flashes.forEach((flash) => {
    setTimeout(() => {
      flash.style.transition = "opacity 0.5s ease";
      flash.style.opacity = "0";
      setTimeout(() => flash.remove(), 500);
    }, 4000);
  });
});
