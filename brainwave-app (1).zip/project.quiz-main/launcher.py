"""Brain Wave desktop launcher: starts the server and opens it in its own app window."""
import os, secrets, shutil, subprocess, sys, threading, time, webbrowser, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)
PORT = int(os.environ.get("PORT", 5000))
PUBLIC = "--public" in sys.argv
URL = f"http://127.0.0.1:{PORT}"

# Persistent secret key so logins survive restarts.
env_path = os.path.join(HERE, ".env")
if not os.path.exists(env_path) or "SECRET_KEY=" not in open(env_path).read():
    with open(env_path, "a") as f:
        f.write(f"SECRET_KEY={secrets.token_hex(32)}\n")
for line in open(env_path):
    if "=" in line and not line.startswith("#"):
        k, v = line.strip().split("=", 1)
        if v:
            os.environ.setdefault(k, v)

def find_browser():
    cands = [
        os.path.expandvars(r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"),
        os.path.expandvars(r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"),
        os.path.expandvars(r"%ProgramFiles%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%LocalAppData%\Google\Chrome\Application\chrome.exe"),
    ]
    for n in ("msedge", "google-chrome", "chromium", "chrome"):
        if shutil.which(n):
            cands.append(shutil.which(n))
    return next((c for c in cands if os.path.exists(c)), None)

def open_window():
    for _ in range(60):
        try:
            urllib.request.urlopen(URL, timeout=1); break
        except Exception:
            time.sleep(0.5)
    b = find_browser()
    if b:
        subprocess.Popen([b, f"--app={URL}", "--window-size=1100,800"])
    else:
        webbrowser.open(URL)

def start_tunnel():
    exe = shutil.which("cloudflared")
    if not exe:
        print("\n[public] cloudflared not found. Install it once with:\n"
              "   winget install Cloudflare.cloudflared\n"
              "then run this again to get a public link.\n")
        return
    p = subprocess.Popen([exe, "tunnel", "--url", URL], stderr=subprocess.PIPE, text=True)
    for line in p.stderr:
        if "trycloudflare.com" in line:
            link = next((w for w in line.split() if "trycloudflare.com" in w), "")
            print(f"\n=== PUBLIC LINK (share this): {link} ===\n")
            break
    for _ in p.stderr:  # keep draining
        pass

if __name__ == "__main__":
    threading.Thread(target=open_window, daemon=True).start()
    if PUBLIC:
        threading.Thread(target=start_tunnel, daemon=True).start()
    from waitress import serve
    from app import app
    print(f"Brain Wave running at {URL}  (close this window to stop)")
    serve(app, host="0.0.0.0" if PUBLIC else "127.0.0.1", port=PORT)
