@echo off
call "%~dp0BrainWave.bat" --public
